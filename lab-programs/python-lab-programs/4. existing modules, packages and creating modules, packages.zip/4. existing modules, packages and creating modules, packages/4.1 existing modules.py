#use existing Modules, Packages

import datetime

today = datetime.date.today()
print("Today's Date:", today)

now = datetime.datetime.now()
print("Current Date and Time:",now)

time = datetime.datetime.now().time()
print("Current time:",time)

date = datetime.date.today()
print(date)
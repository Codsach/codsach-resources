from mypackage import new

print(new.add(5,7))
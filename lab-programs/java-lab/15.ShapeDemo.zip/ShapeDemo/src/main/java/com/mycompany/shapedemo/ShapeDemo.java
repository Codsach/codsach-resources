package com.mycompany.shapedemo;

import java.util.Scanner;
import shape.*;


public class ShapeDemo {

    public static void main(String[] args) {
        double side;
        double base, height;
        double radius;
        
        Square s1 = new Square();
        Triangle t1 = new Triangle();
        Circle c1 = new Circle();
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the Side of the Square");
        side = sc.nextDouble();
        System.out.println("Area of the Square is : "+s1.area(side)+"\n");
        
        System.out.println("Enter the Base of the Triangle");
        base = sc.nextDouble();
        
        System.out.println("Enter the Height of the Triangle");
        height = sc.nextDouble();
        System.out.println("Area of the Triangle is : "+t1.area(base,height)+"\n");
        
        System.out.println("Enter the radius of the Circle");
        radius = sc.nextDouble();
        System.out.println("Area of the Circle is : "+c1.area(radius));
        
    }
}

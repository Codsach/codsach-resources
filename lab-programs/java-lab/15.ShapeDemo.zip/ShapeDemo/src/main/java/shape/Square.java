
package shape;

public class Square {
    double side;
    
    public double area(double s){
        side = s;
        return side * side;
    }
}

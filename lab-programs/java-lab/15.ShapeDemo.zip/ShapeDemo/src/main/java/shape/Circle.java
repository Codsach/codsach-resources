package shape;


public class Circle {
    double radius;
    
    public double area(double r){
        radius = r;
        return 3.14 * radius * radius;
    }
}

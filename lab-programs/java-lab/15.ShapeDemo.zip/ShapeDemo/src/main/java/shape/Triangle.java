package shape;

public class Triangle {
    double base, height;
    
    public double area(double b, double h){
        base = b;
        height = h;
        return 0.5 * base * height;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author Sachin R
 */
public class Cicle {
    double radius;
    
    public double area(double r){
        radius = r;
        return 3.14 * radius * radius;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author Sachin R
 */
public class Square {
    double side;
    
    public double area(double s){
        side = s;
        return side * side;
    }
}

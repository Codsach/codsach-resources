/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapedemo;

import shape.*;
import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class ShapeDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double side,base,height,radius;
        
        Scanner sc = new Scanner(System.in);
        
        Square s1 = new Square();
        Triangle t1 = new Triangle();
        Cicle c1 = new Cicle();
        
        System.out.println("Enter the side of the Square:");
        side = sc.nextDouble();
        System.out.println("Area of the Square is: "+s1.area(side));
        
        System.out.println("Enter the Base of the Triangle:");
        base = sc.nextDouble();
        System.out.println("Enter the Height of the Triangle:");
        height = sc.nextDouble();
        System.out.println("Area of the Triangle is: "+t1.area(base,height));
        
        System.out.println("Enter the Radius of the Circle:");
        radius = sc.nextDouble();
        System.out.println("Area of the Circle is: "+c1.area(radius));
    }
    
}

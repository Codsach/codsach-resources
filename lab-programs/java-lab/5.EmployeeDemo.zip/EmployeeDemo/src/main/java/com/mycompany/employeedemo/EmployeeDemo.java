package com.mycompany.employeedemo;

import java.util.Scanner;

public class EmployeeDemo {

    public static void main(String[] args) {
        String eno,ename;
        int age;
        double basic;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the Employee Number : ");
        eno = sc.nextLine();
        
        System.out.println("Enter the Employee Name : ");
        ename = sc.nextLine();
        
        System.out.println("Enter the age :");
        age = sc.nextInt();
        
        System.out.println("Enter the Basic Salary :");
        basic = sc.nextDouble();
        
        Employee e1 = new Employee(eno,ename,age,basic);
        e1.display();
    }
}

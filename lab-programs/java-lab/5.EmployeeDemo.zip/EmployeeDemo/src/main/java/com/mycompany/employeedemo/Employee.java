package com.mycompany.employeedemo;


public class Employee {
    String eno,ename;
    int age;
    double basic,hra,da,pf,pt,gross,net;
    
    Employee(String n, String name, int a, double b){
        eno = n;
        ename = name;
        age = a;
        basic = b;
    }
    
    void display(){
        if(basic > 20000){
            da = basic * 40/100;
        }else{
            da = basic * 30/100;
        }
        
        hra = basic * 10/100;
        gross = basic + hra + da;
        pf = gross * 12/100;
        pt = gross * 5/100;
        net = gross - pf -pt;
        
        System.out.println("---Employee Details---");
        System.out.println("Employee Number : "+eno);
        System.out.println("Employee Name : "+ename);
        System.out.println("Employee Age : "+age);
        System.out.println("Basic Salary : "+basic);
        System.out.println("HRA : "+hra);
        System.out.println("DA  : "+da);
        System.out.println("PF  : "+pf);
        System.out.println("PT  : "+pt);
        System.out.println("Gross Salary : "+gross);
        System.out.println("Net Salary : "+net);
        
    }
}

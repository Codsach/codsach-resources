package com.mycompany.inheritance;


public class Shape {
    String name;
    
    Shape(String n) {
        name = n;
    }
    
    void display() {
        System.out.println("Shape is " + name);
    }
}

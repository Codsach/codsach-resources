package com.mycompany.inheritance;

class Circle extends Shape {
    double radius;
    
    Circle(String n, double r) {
        super(n);
        radius = r;
    }
    
    void area() {
        double area = 3.14 * radius * radius; 
        System.out.println("Area of the Circle is " + area);
    }
}

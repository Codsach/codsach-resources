package com.mycompany.inheritance;




public class Inheritance {
    public static void main(String[] args) {
        Circle c1 = new Circle("Circle", 6);
        c1.display();
        c1.area();
    }
}

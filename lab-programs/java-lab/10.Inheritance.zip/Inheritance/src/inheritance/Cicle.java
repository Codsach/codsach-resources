/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author Sachin R
 */
public class Cicle extends Shape {
    double radius;
    
    Cicle(String n, double r){
        super(n);
        radius = r;
    }
    
    void area(){
        double a = 3.14 * radius * radius;
        System.out.println("Area of Circle is: "+a);
    }
    
}

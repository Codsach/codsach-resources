/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.applet.Applet;
import java.awt.Graphics;
import java.awt.event.*;

/**
 *
 * @author Sachin R
 */
public class KeyDemo extends Applet implements KeyListener {

    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    public void init() {
        // TODO start asynchronous download of heavy resources
        addKeyListener(this);
    }

    // TODO overwrite start(), stop() and destroy() methods
    String msg;
    
    public void keyPressed(KeyEvent e){
        msg = "key pressed";
        repaint();
    }
    
    public void keyReleased(KeyEvent e){
        msg = "key relesed";
        repaint();
    }
    
    public void keyTyped(KeyEvent e){
        msg = "You pressed the character: "+e.getKeyChar();
        repaint();
    }
    
    public void paint(Graphics g){
        g.drawString(msg,100,100);
    }
}

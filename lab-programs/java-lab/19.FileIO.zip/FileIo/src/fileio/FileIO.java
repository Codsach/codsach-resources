/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileio;

import java.io.*;

/**
 *
 * @author Sachin R
 */
public class FileIO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        // TODO code application logic here
        String file1,file2;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        try{
            System.out.println("Enter the filename to read:");
            file1 = br.readLine();
            
            System.out.println("Enter the filename to write:");
            file2 = br.readLine();
            
            FileInputStream f1 = new FileInputStream(file1);
            FileOutputStream f2 = new FileOutputStream(file2);
            
            int val = 0;
            val = f1.read();
            while(val!=-1){
                f2.write(val);
                val = f1.read();
            }
            f1.close();
            f2.close();
            
            f1 = new FileInputStream(file2);
            val = 0;
            System.out.println("values of file2:");
            val = f1.read();
            while(val!=-1){
                System.out.print((char)val);
                val = f1.read();
            }
            f1.close();
                 
        }
        catch(FileNotFoundException e){
            System.out.println("File is not available");
        }
        catch(Exception e1){
            System.out.println(e1);
        }
    }
    
}

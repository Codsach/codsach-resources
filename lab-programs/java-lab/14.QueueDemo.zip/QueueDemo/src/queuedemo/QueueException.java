/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queuedemo;

/**
 *
 * @author Sachin R
 */
public class QueueException extends Exception{
    public void error(){
        System.out.println("Queue is full");
    }
    
}

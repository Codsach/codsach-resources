/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queuedemo;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class Queue {
    int front, rear, size;
    int q[];
    
    Queue (int s){
        rear = -1;
        front = 0;
        size = s;
        q = new int[size];
    }
    
    public void push() throws QueueException{
        Scanner sc = new Scanner(System.in);
        int item;
        
        if(rear == size-1 ){
            throw new QueueException();
        }else{
            System.out.println("Enter the item to be inserted:");
            item = sc.nextInt();
            rear++;
            q[rear]=item;
        }
    }
    
    
    public void pop(){
        if(rear == -1){
            throw new ArrayIndexOutOfBoundsException();
        }
        System.out.println("Deleted item is :"+q[front]);
        front++;
        if(front > rear){
            rear = -1;
            front = 0;
        }
    }
    
    public void display(){
        if(rear == -1){
            throw new ArrayIndexOutOfBoundsException();
        }
        System.out.println("Elements in Queue are:");
        for(int i=front;i<=rear;i++){
            System.out.println(q[i]);
        }
    }
    
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queuedemo;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class QueueDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Queue q1 = new Queue(5);
        Scanner sc = new Scanner(System.in);
        int choice;
        
        while(true){
            System.out.println("1.Insert\n 2.Delete\n 3.Display\n 4.Exit");
            System.out.println("Enter your choice:");
            choice = sc.nextInt();
            
            switch(choice){
                case 1:
                    try{
                        q1.push();
                        break;
                    }catch(QueueException e){
                        e.error();
                    }
                    break;
                    
                case 2:
                    try{
                        q1.pop();
                        break;
                    }catch(ArrayIndexOutOfBoundsException e){
                        System.out.println("Queue is Empty");
                    }
                    break;
                    
                case 3:
                    try{
                        q1.display();
                        break;
                    }catch(ArrayIndexOutOfBoundsException e){
                        System.out.println("Queue is Empty");
                    }
                    break;
                    
                case 4:
                    System.exit(0);
                    
                default:
                    System.out.println("Invalid choice");
                    
            }
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumofdigits;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Sachin R
 */
public class SumOfDigits {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int n,sum=0,r;
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter a Number:");
        n = Integer.parseInt(br.readLine());
        
        while(n!=0){
            r = n % 10;
            sum = sum + r;
            n = n / 10;
            
        }
        System.out.println("The sum of the digits is:"+sum);
    }
    
}

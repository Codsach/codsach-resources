
class LessBalanceException extends Exception {
    LessBalanceException() {
        System.out.println("Withdrawl amount is not valid");
    }
}
    


package com.mycompany.accountdemo;


 class Account {
    String ano, name;
    double balance;

    Account(String a, String n, double b) {
        ano = a;
        name = n;
        balance = b;
        System.out.println("New Account Opened");
        System.out.println("Account Number :" + ano);
        System.out.println("Name :" + name);
        System.out.println("Balance :" + balance+"\n");
    }

    void deposit(double amount) {
        balance = balance + amount;
        System.out.println("Balance After Deposit :" + balance+"\n");
    }

    void withdraw(double amount) throws LessBalanceException {
        balance = balance - amount;
        System.out.println("Available Balance : " + balance);
        

        if (balance < 500) {
            balance = balance + amount;
            throw new LessBalanceException();
        } else {
            System.out.println("Withdraw Successful\n");
        }
    }

    void displaybalance() {
        System.out.println("Account Number : " + ano + " Name : " + name + " Balance : " + balance+"\n");
    }
}


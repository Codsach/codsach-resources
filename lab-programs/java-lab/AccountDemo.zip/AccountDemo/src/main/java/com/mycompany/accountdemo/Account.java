
 class Account {
    String ano, name;
    double balance;

    Account(String a, String n, double b) {
        ano = a;
        name = n;
        balance = b;
        System.out.println("New Account Opened");
        System.out.println("Account Number :" + ano);
        System.out.println("Name :" + name);
        System.out.println("Balance :" + balance);
    }

    void deposit(double amount) {
        balance = balance + amount;
        System.out.println("Balance After Deposit :" + balance);
    }

    void withdraw(double amount) throws LessBalanceException {
        System.out.println("Available Balance : " + balance);
        balance = balance - amount;

        if (balance < 500) {
            balance = balance + amount;
            throw new LessBalanceException();
        } else {
            System.out.println("Withdraw Successful");
        }
    }

    void displaybalance() {
        System.out.println("Account Number :" + ano + " Name :" + name + " Balance :" + balance);
    }
}


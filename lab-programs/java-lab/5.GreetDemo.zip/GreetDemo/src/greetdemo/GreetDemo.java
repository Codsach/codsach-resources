/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package greetdemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Sachin R
 */
public class GreetDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        String name;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Greet g = new Greet();
        
        System.out.println("Enter the Name:");
        name = br.readLine();
        g.display(name);
    }
    
}

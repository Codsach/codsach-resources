/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prodcon;

/**
 *
 * @author Sachin R
 */
public class Q {
    int n;
    boolean valueSet = false;
    
    synchronized int get(){
        while(!valueSet)
            try{
                wait();
            }
        catch(InterruptedException e){
            System.out.println("InterruptedExceptions caught");
        }
        System.out.println("Got: "+n);
        valueSet = false;
        notify();
        return n;
    }
    
   
    synchronized int put(int n){
        while(valueSet)
            try{
                wait();
            }
        catch(InterruptedException e){
            System.out.println("InterruptedExceptions caught");
        }
        this.n = n;
        valueSet = true;
        System.out.println("Put: "+n);
        notify();
        return n;
    }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oddeven;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Sachin R
 */
public class OddEven {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int n;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Enter the Number:");
        n = Integer.parseInt(br.readLine());
        
        if(n%2==0)
            System.out.println("The given number "+n+"is Even");
        else
            System.out.println("Tehe given number"+n+"is Odd");
        
    }
    
    
}

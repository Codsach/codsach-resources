/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package innerdemo;

/**
 *
 * @author Sachin R
 */
public class Outer {
    int outdata = 10;
    
    void display(){
        Inner i1 = new Inner();
        System.out.println("Accessing from Outer class");
        
        System.out.println("Value of Outer class is: "+outdata);
        System.out.println("Value of Inner class is: "+i1.indata+"\n");
        i1.show();
    }
    
    public class Inner{
        int indata = 20;
        
        void show(){
            System.out.println("Accessing from Inner class");
            
            System.out.println("Value of Inner class is: "+indata);
            System.out.println("Sum of indata and outdata is: "+(indata+outdata));
        }
    }
}

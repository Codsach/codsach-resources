/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package innerdemo;

/**
 *
 * @author Sachin R
 */
public class InnerDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Outer o1 = new Outer();
        o1.display();
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringhandling;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class StringHandling {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String s1;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the String:");
        s1 = sc.nextLine();
        
        StringBuffer sb = new StringBuffer(s1);
        
        System.out.println("Capacity of the String Object: "+sb.capacity());
        System.out.println("Reverse of the String: "+sb.reverse());
        
        String s2 = new String(sb);
        String s3 = s2.toUpperCase();
        
        System.out.println("Uppercase of the String: "+s3);
        
        
        System.out.println("Enter the String to append:");
        s1 = sc.nextLine();
        
        StringBuffer sb1 = new StringBuffer(s3);
        System.out.println("the String after appending: "+sb1.append(s1));
    }
    
}

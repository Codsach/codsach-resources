/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enumeration;

/**
 *
 * @author Sachin R
 */
public class Enumeration {

    /**
     * @param args the command line arguments
     */
    
    enum DayOfWeek{
        monday(1),tuesday(2),wednesday(3),thursday(4),friday(5),saturday(6),sunday(7);
        
        int value;
        
        DayOfWeek(int v){
            value = v;
        }
        
        boolean workDay(){
            if(value<=6)
                return true;
            else 
                return false;
        }
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Verification of Sunday is Workday: "+DayOfWeek.sunday.workDay());
        System.out.println("Verification of Thursday is Workday: "+DayOfWeek.thursday.workDay());
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accountdemo;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class AccountDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Account a[] = new Account[10];
        Scanner sc = new Scanner(System.in);
        
        int i=0;
        String ano,name;
        double amount;
        int choice,k;
        boolean t = false;
        
        while(true){
            System.out.println("1.Open\n2.Deposit\n3.Withdraw\n4.BalanceEnquiry\n5.Exit\n");
            System.out.println("Enter your choice:");
            choice = sc.nextInt();
            sc.nextLine();
            
            switch(choice){
                case 1:
                    System.out.println("---Opening New Account---");
                    
                    System.out.println("Enter the Account Number:");
                    ano = sc.nextLine();
                    
                    System.out.println("Enter the Name:");
                    name = sc.nextLine();
                    
                    System.out.println("Enter the Initial amount((>500)");
                    amount = sc.nextDouble();
                    
                    if(amount<500){
                        System.out.println("You can't create an account wiht less than 500 rupees");
                    }else{
                        a[i]=new Account(ano,name,amount);
                        i++;
                    }
                    break;
                    
                    
                case 2:
                    System.out.println("Enter Account Number:");
                    ano = sc.nextLine();
                    
                    for(k=0;k<i;k++){
                        if(ano.equals(a[k].ano)){
                            t = true;
                            break;
                        }
                    }
                    if(t){
                        System.out.println("Enter deposit amount:");
                        amount = sc.nextDouble();
                        a[k].deposit(amount);
                    }else{
                        System.out.println("Invalid Account");
                    }
                    t=false;
                    break;
                    
                    
                case 3:
                    System.out.println("Enter Account Number:");
                    ano = sc.nextLine();
                    
                    for(k=0;k<i;k++){
                        if(ano.equals(a[k].ano)){
                            t = true;
                            break;
                        }
                    }
                    if(t){
                        System.out.println("Enter withdraw amount");
                        amount = sc.nextDouble();
                        try{
                            a[k].withdraw(amount);
                        }catch(LessBalanceException e){
                            System.out.println(e);
                        }
                    }else{
                        System.out.println("Invalid Account");
                        t=false;
                        break;
                    }
                    break;
                
                        
                case 4:
                    System.out.println("Enter Account Number:");
                    ano = sc.nextLine();
                    
                    for(k=0;k<i;k++){
                        if(ano.equals(a[k].ano)){
                            t = true;
                            break;
                        }
                    }
                    if(t){
                        a[k].displayBalance();
                    }else{
                        System.out.println("Invalid Account");
                    }
                    t=false;
                    break;
                    
                case 5:
                    System.exit(0);
                    
                default:
                    System.out.println("Invalid choice");
            }
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accountdemo;

/**
 *
 * @author Sachin R
 */
public class LessBalanceException extends Exception{
    LessBalanceException(){
        System.out.println("Withdrawl amount is Invalid");
    }
}

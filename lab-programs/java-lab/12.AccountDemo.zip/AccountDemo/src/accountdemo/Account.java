/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accountdemo;

/**
 *
 * @author Sachin R
 */
public class Account {
    String ano,name;
    double balance;
    
    Account(String a, String n, double b){
        ano = a;
        name = n;
        balance = b;
        
        System.out.println("New account opened!");
        System.out.println("Account Number: "+ano);
        System.out.println("Name: "+name);
        System.out.println("Balance: "+balance);
    }
    
    void deposit(double amount){
        balance = balance + amount;
        System.out.println("The balance after deposit is :"+balance);
    }
    
    void withdraw(double amount)throws LessBalanceException{
        balance = balance - amount;
        System.out.println("The balance is :"+balance);
        if(balance<500){
            balance = balance+amount;
            throw new LessBalanceException();
        }else{
            System.out.println("Withdraw Successful!");
        }
    }
    
    void displayBalance(){
        System.out.println("Account Number:"+ano+" Name:"+name+" Balance:"+balance);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Sachin R
 */
public class Swap {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int a,b;
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Enter the values of a and b:");
        a = Integer.parseInt(br.readLine());
        b = Integer.parseInt(br.readLine());
        
        System.out.println("Values Before Swapping a = "+a+",b = "+b);
        a = a + b;
        b = a - b;
        a = a - b;
        System.out.println("Values After Swapping a = "+a+",b = "+b);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.applet.Applet;
import java.awt.*;
/**
 *
 * @author Sachin R
 */
public class Chess extends Applet {

    /**
     * Initialization method that will be called after the applet is loaded into
     * the browser.
     */
    public void init() {
        // TODO start asynchronous download of heavy resources
        
    }

    // TODO overwrite start(), stop() and destroy() methods
    public void paint(Graphics g){
        int row,col,x,y;
        
        for(row=0;row<8;row++){
            for(col=0;col<8;col++){
               x=row*80;
               y=col*80;
               
               if((row%2)==(col%2))
                   g.setColor(Color.white);
               else
                   g.setColor(Color.black);
                   g.fillRect(x, y, 80, 80);
            }
        }
    }
}

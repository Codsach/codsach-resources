




interface rectangle {
    void rectArea(double l, double b);
}

interface triangle {
    void triArea(double b, double h);
}

class Area implements rectangle, triangle {
    public void rectArea(double l, double b) {
        double result = l * b;
        System.out.println("Area of Rectangle is : " + result);
    }

    public void triArea(double b, double h) {
        double result = 0.5 * b * h;
        System.out.println("Area of Triangle is : " + result);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multipleinheritance;

import java.util.Scanner;



public class MultipleInheritance {
    public static void main(String[] args) {
        double length, breadth, base, height;

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length & Breadth of the rectangle");
        length = sc.nextDouble();
        breadth = sc.nextDouble();

        System.out.println("Enter the Base and Height of the Triangle");
        base = sc.nextDouble();
        height = sc.nextDouble();

        Area a1 = new Area();
        a1.rectArea(length, breadth);
        a1.triArea(base, height);
    }
}


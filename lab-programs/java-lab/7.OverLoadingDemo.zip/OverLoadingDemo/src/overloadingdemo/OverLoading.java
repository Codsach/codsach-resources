/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overloadingdemo;

/**
 *
 * @author Sachin R
 */
public class OverLoading {
    double height;
    double width;
    double depth;
    
    OverLoading(){
        height = 0;
        width = 0;
        depth = 0;
    }
    
    OverLoading(double w, double h, double d){
        height = h;
        width = w;
        depth = d;
    }
    
    double volume(){
        return height * width * depth;
    }
    
    double rectArea(double l, double b){
        return l * b;
    }
    
    double rectArea(double a){
        return a * a;
    }
}

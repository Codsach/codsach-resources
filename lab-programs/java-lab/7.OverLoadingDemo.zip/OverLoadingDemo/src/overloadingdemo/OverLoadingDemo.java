/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overloadingdemo;

/**
 *
 * @author Sachin R
 */
public class OverLoadingDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        OverLoading o1 = new OverLoading();
        OverLoading o2 = new OverLoading(5,6,7);
        
        double v1,v2;
        double a1,a2;
        
        v1 = o1.volume();
        v2 = o2.volume();
        
        a1 = o1.rectArea(5,4);
        a2 = o1.rectArea(5);
        
        System.out.println("Volume of box1:"+v1);
        System.out.println("Volume of box2:"+v2);
        
        System.out.println("Area of Rectangle:"+a1);
        System.out.println("Area of Rectangle:"+a2);
    }
    
}

package com.mycompany.stringhandling;

import java.util.Scanner;


public class StringHandling {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the String");
        String s1 = sc.nextLine();
        
        StringBuffer sb = new StringBuffer(s1);
        
        System.out.println("Capacity of String Buffer object is : "+sb.capacity());
        System.out.println("Reverse of the String is : "+sb.reverse());
        
        String s2 = new String(sb);
        String s3  =s2.toUpperCase();
        
        System.out.println("String in Uppercase : "+s3);
        
        System.out.println("Enter string to append : ");
        s1 = sc.nextLine();
        
        StringBuffer sb1 = new StringBuffer(s3);
        
        System.out.println("The resultant string buffer after appending : "+sb1.append(s1));
        
        
    }
}

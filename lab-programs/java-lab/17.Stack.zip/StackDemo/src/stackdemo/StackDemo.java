/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackdemo;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class StackDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int choice;
        
        Scanner sc = new Scanner(System.in);
        
        while(true){
            System.out.println("1.Fixedstack\n 2.Dynamicstack\n 3.Exit\n");
            System.out.println("Enter your choice: ");
            choice = sc.nextInt();
            
            switch(choice){
                case 1:
                    FixedStack f1 = new FixedStack();
                    
                    while(true){
                        System.out.println("1.Push\n 2.Pop\n 3.Display\n 4.Menu\n");
                        System.out.println("Enter your choice:");
                        choice = sc.nextInt();
                        
                        switch(choice){
                            case 1: 
                                f1.push(); 
                                break;
                            case 2: 
                                f1.pop(); 
                                break;
                            case 3: 
                                f1.display(); 
                                break;
                            case 4:
                                break;
                                
                        }
                        
                        if(choice == 4)
                            break;
                        
                    }
                    break;
                    
                case 2:
                    System.out.println("Enter the Size:");
                    int size = sc.nextInt();
                    
                    DynamicStack d1 = new DynamicStack(size);
                    
                    while(true){
                        System.out.println("1.Push\n 2.Pop\n 3.Display\n 4.Menu\n");
                        System.out.println("Enter your choice:");
                        choice = sc.nextInt();
                        
                        switch(choice){
                            case 1: 
                                d1.push(); 
                                break;
                            case 2: 
                                d1.pop(); 
                                break;
                            case 3: 
                                d1.display(); 
                                break;
                            case 4:
                                break;
                                
                        }
                        
                        if(choice == 4)
                            break;
                        
                    }
                    break;
                    
                    
                case 3:
                    System.exit(0);
                }
            }
        }
    }
    


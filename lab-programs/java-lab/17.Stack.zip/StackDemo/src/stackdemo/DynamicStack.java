/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackdemo;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class DynamicStack {
    int s[];
    int top = -1;
    
    DynamicStack(int size){
        s = new int[size];
    }
    
    public void push(){
        if(top == s.length-1){
            System.out.println("Stack Overflow!");
            return;
        }
        Scanner sc = new Scanner(System.in);
        
        top++;
        System.out.println("Enter the item to be inserted:");
        int item =sc.nextInt();
        s[top] = item;    
    }
    
    public void pop(){
        if(top == -1){
            System.out.println("Stack Underflow!");
            return;
        }
        System.out.println("Item deleted "+s[top]);
        top--;
    }
    
    public void display(){
        if(top == -1){
            System.out.println("Stack is Empty");
            return;
        }
        System.out.println("The elements are:");
        for(int i=top;i>=0;i--)
            System.out.println(s[i]);
    }
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multipleinheritance;

/**
 *
 * @author Sachin R
 */
public class Area implements Rectangle, Triangle{
    
    public void rectArea(double l, double b){
        double result = l * b;
        System.out.println("Area of the Rectangle is: "+result);
    }
    
    public void triArea(double b, double h){
        double result = 0.5 * b * h;
        System.out.println("Area of the Triangle is: "+result);
   
    }
}

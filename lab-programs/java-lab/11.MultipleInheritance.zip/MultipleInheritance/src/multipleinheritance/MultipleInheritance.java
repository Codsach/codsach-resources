/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multipleinheritance;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class MultipleInheritance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double length, breadth, base, height;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the Length and Breadth of the Rectangle");
        length = sc.nextDouble();
        breadth = sc.nextDouble();
        
        System.out.println("Enter the Base and Height of the Triangle");
        base = sc.nextDouble();
        height = sc.nextDouble();
        
        Area a1 = new Area();
        a1.rectArea(length, breadth);
        a1.triArea(base, height);
    }
    
}

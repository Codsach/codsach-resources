/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recurssion;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class Recurssion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n,result;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter a Number:");
        n = sc.nextInt();
        
        Factorial f = new Factorial();
        
        result = f.fact(n);
        System.out.println("Factorial of a Number is:"+result);
        
    }
    
}

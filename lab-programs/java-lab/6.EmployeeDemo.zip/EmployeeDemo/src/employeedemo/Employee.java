/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeedemo;

/**
 *
 * @author Sachin R
 */
public class Employee {
    String eno;
    String ename;
    int age;
    double basic;
    double da;
    double hra;
    double pf;
    double pt;
    double gross,net;
    
    Employee(String e, String n, int a, double b){
        eno = e;
        ename = n;
        age = a;
        basic = b;
    }
    
    void display(){
        if(basic >= 20000)
            da = basic * 40 / 100;
        else
            da = basic * 30 / 100;
        
        hra = basic * 10 / 100;
        gross = basic + da + hra;
        pf = gross * 12 / 100;
        pt = gross * 5 / 100;
        net = gross - pf - pt;
        
        System.out.println("---The Employee Details---");
        System.out.println("Employee Number: "+eno);
        System.out.println("Employee Name: " +ename);
        System.out.println("Age: "+age);
        System.out.println("Basic Salary: "+basic);
        System.out.println("DA: "+da);
        System.out.println("HRA: "+hra);
        System.out.println("PF: "+pf);
        System.out.println("PT: "+pt);
        System.out.println("Gross salary: "+gross);
        System.out.println("Net salary: "+net);
    }
}

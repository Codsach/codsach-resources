/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeedemo;

import java.util.Scanner;

/**
 *
 * @author Sachin R
 */
public class EmployeeDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the Employee number");
        String eno = sc.nextLine();
        
        System.out.println("Enter the Employee name");
        String ename = sc.nextLine();
        
        System.out.println("Enter the age");
        int age = sc.nextInt();
        
        System.out.println("Enter the Basic salary");
        double basic = sc.nextDouble();
        
        Employee e1 = new Employee(eno,ename,age,basic);
        e1.display();
    }
    
}
